# AW Scenario C (SQL Server + PostgreSQL) - multi-root forest

One pipeline, three logical connections. SQL Server loads use `sql_command`; PostgreSQL uses Parquet extract + `staged-database-sql`.

## Topology (ADR 0023)

This DAG is a **multi-root forest**: several steps have no upstream edges and become Ready together.

Typical structural roots:

1. `extract_sales_order`
2. `extract_sales_line`
3. `load_sales_order_sqlserver` (SS path re-queries AdventureWorks; it does not depend on the extracts)

Contrast with Lab **D** (single-root fan-out) and Lab **E** (single-root parquet -> artifact-sql -> dual staged sinks).

## Failure policy testing

Import, publish, then set run-level `dag_failure_policy` to `continue_independent` (pipeline default or deployment override) and fail one independent branch (for example break the SS MERGE). Sibling roots/branches should keep running. With `fail_fast`, only a `fail_pipeline` step failure latches the whole run.

## Connections

- `aw-source` - AdventureWorks extracts (PostgreSQL path)
- `aw-sql-dest` - SQL Server migrations and MERGE loads
- `aw-pg-dest` - PostgreSQL migrations and staged loads

## Steps

1. `extract_sales_order` / `extract_sales_line` (source -> parquet)
2. `load_sales_order_sqlserver` -> `load_sales_line_sqlserver`
3. `load_sales_order_postgres` / `load_sales_line_postgres` (artifact_available from extracts)

SS and PG branches run independently after extracts; there is no distributed transaction across destinations.

## Runtime flags

PostgreSQL half requires `Querial:Extensions:Artifacts` and `Querial:Extensions:DuckDb`.

## Staged SQL reference (SS)

Reference-only under this package (promoted to real steps in Lab **E**):

- `sql/reference/031_load_sales_order_sqlserver_staged.sql`
- `sql/reference/051_load_sales_line_sqlserver_staged.sql`