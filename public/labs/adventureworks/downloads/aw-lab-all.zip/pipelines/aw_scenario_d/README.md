# AW Scenario D - single-root fan-out

One extract is the **only** structural root. Both destination loads depend on it.

## Topology (ADR 0023)

```text
extract_sales_order  (ROOT)
  |--(succeeded)----------> load_sales_order_sqlserver   (sql_command, re-queries source)
  +--(artifact_available)-> load_sales_order_postgres  (staged-database-sql)
```

Contrast with Lab **C**: C is a **multi-root forest** (independent extracts and an unbound SS load start together). D forces a shared upstream so there is exactly one entry point.

## Failure policy

- SS load uses step `failure_policy: continue` so a SS MERGE failure does not latch fail-fast; the PG branch can still finish under run-level `fail_fast`.
- Optionally set pipeline/deployment `dag_failure_policy` to `continue_independent` to keep independent branches alive when a `fail_pipeline` step fails elsewhere.

## Connections

- `aw-source` - extract
- `aw-sql-dest` - migrations + MERGE
- `aw-pg-dest` - migrations + staged load

## Runtime flags

PostgreSQL branch requires `Querial:Extensions:Artifacts` and `Querial:Extensions:DuckDb`.