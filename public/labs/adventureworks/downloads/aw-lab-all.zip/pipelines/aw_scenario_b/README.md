# AW Scenario B (PostgreSQL destination)

This pipeline extracts AdventureWorks products to Parquet and loads them into PostgreSQL via staged-database-sql.

## Connections

- `aw-source` for `database-query-to-parquet` extract.
- `aw-pg-dest` for migrations and `staged-database-sql` load.

## Steps

1. `extract_product` (`database-query-to-parquet`) writes artifact `product`.
2. `load_product` (`staged-database-sql`) stages that artifact as `product` and upserts into `aw.product`.

Dependency `extract_product` -> `load_product` uses `artifact_available`.

## Runtime flags

Requires `Querial:Extensions:Artifacts` and `Querial:Extensions:DuckDb` (Aspire AppHost enables both for local lab).