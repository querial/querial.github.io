# AW Scenario E - Artifact SQL (DuckDB)

Full Parquet path with a **single structural root**. This lab is the Artifact SQL teaching package:

1. Single-input `artifact-sql` (CAST/filter on one Parquet).
2. Multi-input `artifact-sql` (INNER JOIN + GROUP BY over two Parquet artifacts).
3. Dual `staged-database-sql` sinks (SQL Server and PostgreSQL) — including the DuckDB rollup table `aw.sales_order_summary`.

There is no database connection on `artifact-sql` steps. DuckDB runs embedded in an eligible agent.

## Topology (ADR 0023)

```text
extract_sales_order (ROOT, parquet)
  |--(artifact_available)-> transform_sales_order (artifact-sql, one input)
  |                           |--> load_sales_order_sqlserver (staged)
  |                           +--> load_sales_order_postgres (staged)
  |                           +--> transform_order_summary (artifact-sql, TWO inputs)
  |                                 |--> load_order_summary_sqlserver (staged)
  |                                 +--> load_order_summary_postgres (staged)
  +--(succeeded)----------> extract_sales_line
                              +--(artifact_available)-> transform_sales_line (artifact-sql, one input)
                                                          |--> load_sales_line_sqlserver (staged)
                                                          +--> load_sales_line_postgres (staged)
                                                          +--> transform_order_summary (second input)
```

All artifact edges use `artifact_available`. Line extract hangs off the order extract so the graph stays single-root (unlike Lab **C**).

## DuckDB SQL

- `transform_sales_order` / `transform_sales_line` read `{{ input.sales_order }}` / `{{ input.sales_line }}` (one `from_step` each).
- `transform_order_summary` joins both transformed artifacts:

```sql
FROM {{ input.sales_order }} AS o
INNER JOIN {{ input.sales_line }} AS l
    ON o.sales_order_id = l.sales_order_id
GROUP BY ...
```

`config.inputs.<name>.from_step` must match those input names. `config.outputName` is required and unique.

## Lab contrast

| Lab | Focus |
|-----|--------|
| **B** | Minimal PG: extract -> staged PG only |
| **C** | Multi-root forest; SS `sql_command` + PG staged (mixed) |
| **D** | Topology + failure policy: single-root fan-out |
| **E** | Artifact SQL: extract -> DuckDB (cast + join) -> dual staged sinks |

SS staged MERGE scripts are **real steps** here (promoted from C `sql/reference/031_*` / `051_*`).

## Connections

- `aw-source` - extracts
- `aw-sql-dest` - migrations + staged MERGE
- `aw-pg-dest` - migrations + staged upsert

## Runtime flags (required)

Requires **both**:

- `Querial:Extensions:Artifacts=true`
- `Querial:Extensions:DuckDb=true`

Aspire AppHost enables these for local lab runs.

## Failed-cone recovery (ADR 0027 Lab E)

1. Run the pipeline with `DagExecution=true` (plus Artifacts + DuckDb).
2. Fail **one** staged sink (for example `load_sales_order_sqlserver`) while the extract, `artifact-sql` transforms, and the sibling sink succeed.
3. Retry the failed run with mode **failed cone** (not full).
4. Confirm: the failed sink is the only step leased again; extract and transforms stay `succeeded` with `outcome_reason=reused`; cloned artifact checksums match the source; the sibling sink is not re-executed.

Full retry still re-extracts. Same-agent ArtifactLocalizer cache (no re-download) is not skip-extract.