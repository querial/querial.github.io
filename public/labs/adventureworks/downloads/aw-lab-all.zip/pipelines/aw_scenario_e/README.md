# AW Scenario E - artifact-sql spine

Full Parquet / DuckDB path with a **single structural root**.

## Topology (ADR 0023)

```text
extract_sales_order (ROOT)
  |--(artifact_available)-> transform_sales_order (artifact-sql)
  |                           |--> load_sales_order_sqlserver (staged)
  |                           +--> load_sales_order_postgres (staged)
  +--(succeeded)----------> extract_sales_line
                              +--(artifact_available)-> transform_sales_line (artifact-sql)
                                                          |--> load_sales_line_sqlserver (staged)
                                                          +--> load_sales_line_postgres (staged)
```

All artifact edges use `artifact_available`. Line extract hangs off the order extract so the graph stays single-root (unlike Lab **C**).

## Lab contrast

| Lab | Focus |
|-----|--------|
| **B** | Minimal PG: extract -> staged PG only |
| **C** | Multi-root forest; SS `sql_command` + PG staged (mixed) |
| **D** | Topology + failure policy: single-root fan-out |
| **E** | Full spine: extract -> `artifact-sql` -> dual staged sinks |

SS staged MERGE scripts are **real steps** here (promoted from C `sql/reference/031_*` / `051_*`).

## Connections

- `aw-source` - extracts
- `aw-sql-dest` - migrations + staged MERGE
- `aw-pg-dest` - migrations + staged upsert

## Runtime flags (required)

Requires **both**:

- `Querial:Extensions:Artifacts=true`
- `Querial:Extensions:DuckDb=true`

Aspire AppHost enables these for local lab runs.