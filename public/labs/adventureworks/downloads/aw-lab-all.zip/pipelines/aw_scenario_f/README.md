# AW Scenario F - External Parquet ingest

Upload a tiny Parquet file at **trigger** time. Querial seeds it as the `ids` artifact, then `staged-database-sql` upserts into PostgreSQL `ingest.ids`.

**Do not create a schedule** for this version. Cron create/enable is refused; a leftover fire fails closed.

This scenario does not read AdventureWorks. It uses the same `aw-pg-dest` warehouse as B-E.

## Fixture

Multipart field name: `parquet.ids`

Canonical file: `lab/adventureworks/fixtures/tiny-ids.parquet` (same generated three-row `id` file as the Trigger Demo). Copied into the package as `fixtures/tiny-ids.parquet`.

## Connections

- `aw-pg-dest` - PostgreSQL destination. Bind to Aspire **target-pg** database `querial_test` (host `127.0.0.1`, port `15434`). Stub only in the package; no secrets.

## Parameters

| Code | Type | Required | Notes |
|------|------|----------|--------|
| `batch_label` | string | yes | Default `lab`. Sent on JSON or multipart `parameters`. The sink table does not store it; it exists so Run now / Trigger Demo show a typed field next to the file. |

## Steps

1. `ingest_ids` (`external-parquet`) - structural root, `outputName: ids`, `retentionDays: 30`, no connection, no SQL.
2. `load_ids` (`staged-database-sql`) - stages `ids` and upserts `ingest.ids`.

Dependency uses `artifact_available`.

## Lab contrast

| Lab | Focus |
|-----|--------|
| **E** | Extract AdventureWorks to Parquet, DuckDB transforms, dual staged sinks |
| **F** | Upload Parquet at trigger (`external-parquet`) into PostgreSQL only |

## Runtime flags

Requires **Artifacts** and **DagExecution** (Aspire AppHost already sets `ApiKeys`, `DagExecution`, `Artifacts`, and `DuckDb`).

## How to run

1. Import `packages/scenario-f-ingest/` (or `aw-lab-all` then publish `aw_scenario_f`).
2. Connection wizard: map `aw-pg-dest` to target-pg / `querial_test`.
3. Publish the pipeline. Deploy to a non-production environment.
4. **Run now** (or Trigger Demo / `POST /api/trigger` multipart): set `batch_label`, attach the fixture as `parquet.ids`.
5. JSON-only trigger of this version -> 400.
6. Confirm Artifact details shows expiry; `SELECT * FROM ingest.ids` in pgAdmin (`17543`).