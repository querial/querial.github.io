# AW Scenario A (SQL Server destination)

This pipeline imports the AdventureWorks person/customer subset into SQL Server destination tables under schema `aw`.

## Connections

- `aw-sql-dest` for migrations and load steps.
- `aw-source` is present in the package catalog for consistency with lab naming, but Scenario A uses same-instance three-part names and does not bind extract steps.

## Steps

1. `load_person` from `AdventureWorks.Person.Person` into `aw.person`.
2. `load_customer` from `AdventureWorks.Sales.Customer` into `aw.customer` (depends on `load_person`).

All steps are `sql_command` and idempotent (`MERGE`).